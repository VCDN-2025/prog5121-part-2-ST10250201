import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MessageTest {

    private Message message;

    @BeforeEach
    public void setup() {
        message = new Message();
    }

    @Test
    public void testCheckMessageID_ValidLength() {
        message.setMessageID("1234567890"); // 10 chars
        assertTrue(message.checkMessageID());
    }

    @Test
    public void testCheckMessageID_InvalidLength() {
        message.setMessageID("12345678901"); // 11 chars
        assertFalse(message.checkMessageID());
    }

    @Test
    public void testCheckRecipientCell_Valid() {
        assertEquals(0, message.checkRecipientCell("+2712345678")); // valid + and <= 10 chars
    }

    @Test
    public void testCheckRecipientCell_TooLong() {
        assertEquals(1, message.checkRecipientCell("+271234567890")); // too long
    }

    @Test
    public void testCheckRecipientCell_MissingPlus() {
        assertEquals(2, message.checkRecipientCell("2712345678")); // missing +
    }

    @Test
    public void testCheckMessageLength_Valid() {
        String validMsg = "Hello, this is a valid message under 250 chars.";
        assertTrue(message.checkMessageLength(validMsg));
    }

    @Test
    public void testCheckMessageLength_Invalid() {
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 251; i++) {
            longMsg.append("a");
        }
        assertFalse(message.checkMessageLength(longMsg.toString()));
    }

    @Test
    public void testGenerateMessageID_LengthAndDigits() {
        message.generateMessageID();
        String id = message.getMessageID();
        assertNotNull(id);
        assertEquals(10, id.length());
        assertTrue(id.matches("\\d{10}")); // only digits
    }

    @Test
    public void testCreateMessageHash() {
        message.setMessageID("1234567890");
        message.setNumMessagesSent(0);
        message.setMessage("Hi Mike, can you join us for dinner tonight");
        String expectedHash = "12:0:HITHONIGHT";
        assertEquals(expectedHash, message.createMessageHash());
    }

    @Test
    public void testSentMessage_Send() {
        assertEquals("Message successfully sent.", message.sentMessage("1"));
    }

    @Test
    public void testSentMessage_Disregard() {
        assertEquals("Press O to delete message.", message.sentMessage("2"));
    }

    @Test
    public void testSentMessage_Store() {
        assertEquals("Message successfully stored.", message.sentMessage("3"));
    }

    @Test
    public void testSentMessage_InvalidOption() {
        assertEquals("Invalid option selected.", message.sentMessage("99"));
    }
}
