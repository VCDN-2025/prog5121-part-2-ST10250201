import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        
        Login user = new Login("user_", "Passw0rd!", "+27123456789", "John", "Doe");

        // Login
        String inputUsername = JOptionPane.showInputDialog("Enter username:");
        String inputPassword = JOptionPane.showInputDialog("Enter password:");

        if (!user.loginUser(inputUsername, inputPassword)) {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");

        List<Message> sentMessages = new ArrayList<>();
        int totalMessagesSent = 0;

        // Ask how many messages user wants to send
        int maxMessages = 0;
        while (maxMessages <= 0) {
            try {
                maxMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to enter?"));
                if (maxMessages <= 0) {
                    JOptionPane.showMessageDialog(null, "Please enter a positive number.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid number. Try again.");
            }
        }

        boolean quit = false;

        while (!quit) {
            String choice = JOptionPane.showInputDialog("""
                Choose an option:
                1) Send Messages
                2) Show Recently Sent Messages
                3) Quit
            """);

            switch (choice) {
                case "1" -> {
                    for (int i = 0; i < maxMessages; i++) {
                        Message message = new Message();

                      
                        String recipient = JOptionPane.showInputDialog("Enter recipient cell number (max 10 chars, must start with +):");
                        while (message.checkRecipientCell(recipient) != 0) {
                            JOptionPane.showMessageDialog(null, "Invalid number. Try again.");
                            recipient = JOptionPane.showInputDialog("Enter recipient cell number (start with +):");
                        }
                        message.setRecipient(recipient);

                      
                        String msg = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                        while (!message.checkMessageLength(msg)) {
                            int extra = msg.length() - 250;
                            JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + extra);
                            msg = JOptionPane.showInputDialog("Enter your message again:");
                        }
                        message.setMessage(msg);

                        
                        message.setNumMessagesSent(totalMessagesSent);
                        message.generateMessageID();
                        message.setMessageHash(message.createMessageHash());

                       
                        String sendOption = JOptionPane.showInputDialog("""
                                                                                                    Choose an option:
                                                                                                    1) Send Message
                                                                                                    2) Disregard Message
                                                                                                    3) Store Message
                                                                                                """);

                        String result = message.sentMessage(sendOption);

                        switch (result) {
                            case "Message successfully sent." -> {
                                sentMessages.add(message);
                                totalMessagesSent++;
                                JOptionPane.showMessageDialog(null, message.displayMessageDetails());
                            }
                            case "Message successfully stored." -> {
                                message.storeMessage();
                                JOptionPane.showMessageDialog(null, "Message stored.");
                            }
                            case "Press O to delete message." -> JOptionPane.showMessageDialog(null, "Message discarded.");
                            default -> JOptionPane.showMessageDialog(null, "Invalid option, message disregarded.");
                        }
                    }
                    JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
                }

                case "2" -> {
                    if (sentMessages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages sent yet.");
                    } else {
                        StringBuilder recent = new StringBuilder("Recent Messages:\n");
                        for (Message m : sentMessages) {
                            recent.append("\n").append(m.displayMessageDetails()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, recent.toString());
                    }
                }

                case "3" -> quit = true;

                default -> JOptionPane.showMessageDialog(null, "Invalid selection. Choose 1, 2, or 3.");
            }
        }

        JOptionPane.showMessageDialog(null, "Thank you for using QuickChat. Goodbye!");
    }
}
